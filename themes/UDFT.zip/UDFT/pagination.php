<div class="pagination">
	<?php paginate_links( ) ?>
</div>
