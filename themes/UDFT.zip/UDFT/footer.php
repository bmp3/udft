            <?php
                udft::finish_content_layout();
            ?>

                </div> <!-- content-body-wrap -->

            </div> <!-- content-wrap -->


			<footer class="footer" role="contentinfo">


			</footer>

		</div>

		<?php wp_footer(); ?>

	</body>
</html>
